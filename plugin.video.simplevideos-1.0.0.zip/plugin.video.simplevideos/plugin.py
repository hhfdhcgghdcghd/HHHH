# -*- coding: utf-8 -*-
import sys
import urllib.parse as urlparse
from urllib.parse import parse_qs, urlencode
import xbmcplugin
import xbmcgui

ADDON_HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

# Sample video list: title, url, thumbnail, mark/label
VIDEOS = [
    {
        "title": "Big Buck Bunny [HD]",
        "url": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
        "thumbnail": "special://home/addons/plugin.video.simplevideos/resources/icon.png",
        "mark": "[HD]"
    },
    {
        "title": "Sintel [NEW]",
        "url": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
        "thumbnail": "special://home/addons/plugin.video.simplevideos/resources/icon.png",
        "mark": "[NEW]"
    },
    {
        "title": "Tears of Steel [4K]",
        "url": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
        "thumbnail": "special://home/addons/plugin.video.simplevideos/resources/icon.png",
        "mark": "[4K]"
    },
]

def build_url(query):
    return BASE_URL + '?' + urlencode(query)

def list_videos():
    for item in VIDEOS:
        # Show mark in label2, keep title clean
        list_item = xbmcgui.ListItem(label=item['title'])
        list_item.setArt({'thumb': item['thumbnail'], 'icon': item['thumbnail'], 'poster': item['thumbnail']})
        list_item.setInfo('video', {'title': item['title'], 'genre': 'Demo', 'plot': f"Sample clip {item['mark']}", 'tagline': item['mark']})
        list_item.setProperty('IsPlayable', 'true')
        url = build_url({'action': 'play', 'video_url': item['url']})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=list_item, isFolder=False)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def play_video(video_url):
    list_item = xbmcgui.ListItem(path=video_url)
    list_item.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, list_item)

def router(paramstring):
    params = parse_qs(paramstring)
    action = params.get('action', [None])[0]
    if action == 'play':
        video_url = params.get('video_url', [None])[0]
        if video_url:
            play_video(video_url)
        else:
            xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
    else:
        list_videos()

if __name__ == '__main__':
    router(sys.argv[2][1:])
